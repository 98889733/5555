Island Builder — запускать index.html (нужен интернет при запуске: three.js грузится с cdnjs).
Ориентация: landscape (manifest.json + screen.orientation.lock). Если сборщик APK умеет задавать ориентацию — поставьте "landscape".
